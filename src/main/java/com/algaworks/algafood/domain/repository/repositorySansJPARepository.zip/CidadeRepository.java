package com.algaworks.algafood.domain.repository;

import com.algaworks.algafood.domain.model.Cidade;
import com.algaworks.algafood.domain.model.Estado;

import java.util.List;

public interface CidadeRepository {

    List<Cidade> list ();
    Cidade findById (Long id);
    List<Cidade> findByEstado (Estado estado);
    Cidade save (Cidade cidade);
    void remove (Long id);
}
