package com.algaworks.algafood.domain.repository;

import com.algaworks.algafood.domain.model.FormaPagamento;
import org.springframework.stereotype.Component;

import java.util.List;

public interface FormaPagamentoRepository {

    List<FormaPagamento> list();
    FormaPagamento findById(Long id);
    void save(FormaPagamento formaPagamento);
    void remove (FormaPagamento formaPagamento);
}
