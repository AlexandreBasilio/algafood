package com.algaworks.algafood.domain.repository;

import com.algaworks.algafood.domain.model.Cozinha;
import org.hibernate.type.ListType;
import org.springframework.dao.EmptyResultDataAccessException;

import java.util.List;

public interface CozinhaRepository {
    // Orientado a persistencia       Orientado a colecao
    List<Cozinha> list ();         // all
    List<Cozinha> listByNome(String nome);
    Cozinha findById (Long id);    // byId
    Cozinha save (Cozinha cozinha);   // add
    void remove (Long id); // remove
}
